
"use client";

import * as React from "react";
import { useParams, useRouter } from 'next/navigation';
import { useLocalStorage } from "@/hooks/use-local-storage";
import type { Customer, Order, Plate, Payment } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, IndianRupee, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
  } from "@/components/ui/table";
import { format } from "date-fns";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import {
    AlertDialog,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogHeader,
    AlertDialogTitle,
  } from "@/components/ui/alert-dialog";
import { Loader2 } from "lucide-react";

export default function CustomerHistoryPage() {
    const router = useRouter();
    const params = useParams();
    const { toast } = useToast();
    const customerId = params.customerId as string;

    const [customers, setCustomers] = useLocalStorage<Customer[]>("customers", []);
    const [orders, setOrders] = useLocalStorage<Order[]>("orders", []);
    const [plates] = useLocalStorage<Plate[]>("plates", []);
    const [payments, setPayments] = useLocalStorage<Payment[]>("payments", []);
    const [paymentAmount, setPaymentAmount] = React.useState<number | string>("");
    const [redirectingOrder, setRedirectingOrder] = React.useState<Order | null>(null);

    const customer = customers.find((c) => c.id === customerId);

    const customerOrders = orders
        .filter((order) => order.customerId === customerId)
        .map((order) => ({
            ...order,
            customerName: customer?.name || "Unknown",
            items: order.items.map((item) => ({
                ...item,
                plateName: plates.find((p) => p.id === item.plateId)?.name || "Unknown",
            })),
            rentalDate: new Date(order.rentalDate),
        }))
        .sort((a, b) => b.rentalDate.getTime() - a.rentalDate.getTime());
    
    const customerPayments = payments
        .filter((p) => p.customerId === customerId)
        .map(p => ({...p, paymentDate: new Date(p.paymentDate)}))
        .sort((a, b) => b.paymentDate.getTime() - a.paymentDate.getTime());

    const totalRentalAmount = customerOrders.reduce((sum, order) => sum + order.rentalAmount, 0);
    const totalPaidAmount = customerPayments.reduce((sum, payment) => sum + payment.amount, 0);
    const outstandingBalance = totalRentalAmount - totalPaidAmount;

    React.useEffect(() => {
        if(customer && customer.outstandingBalance !== outstandingBalance) {
            setCustomers(prev => prev.map(c => 
                c.id === customerId 
                ? { ...c, outstandingBalance: outstandingBalance }
                : c
            ));
        }
    }, [customerId, customer, outstandingBalance, setCustomers]);


    const handleAddPayment = () => {
        const amount = Number(paymentAmount);
        if (!customer || !amount || amount <= 0) {
            toast({
                variant: "destructive",
                title: "Invalid Amount",
                description: "Please enter a valid positive amount.",
            });
            return;
        }

        const newPayment: Payment = {
            id: `pay_${Date.now()}`,
            customerId,
            amount,
            paymentDate: new Date(),
        };
        setPayments(prev => [newPayment, ...prev]);

        toast({
            title: "Payment Recorded",
            description: `${new Intl.NumberFormat("en-IN", { style: 'currency', currency: 'INR' }).format(amount)} has been recorded for ${customer.name}.`,
        });
        setPaymentAmount("");
    };

    const handleDeletePayment = (paymentToDelete: Payment) => {
        if (!customer) return;
    
        // Remove the payment from the list
        setPayments(prev => prev.filter(p => p.id !== paymentToDelete.id));
    
        toast({
            title: "Payment Deleted",
            description: `Payment of ${new Intl.NumberFormat("en-IN", { style: 'currency', currency: 'INR' }).format(paymentToDelete.amount)} has been removed.`,
        });
    };
    
    const handleViewOrder = (order: Order) => {
        setRedirectingOrder(order);
        setTimeout(() => {
          router.push(`/orders/${order.id}`);
        }, 1000); 
    };

    if (!customer) {
        return (
            <div className="flex flex-col items-center justify-center h-full text-center">
                <p className="text-lg text-muted-foreground">Customer not found.</p>
                <Button onClick={() => router.back()} className="mt-4">
                    <ArrowLeft className="mr-2 h-4 w-4" /> Go Back
                </Button>
            </div>
        )
    }

    return (
        <div className="space-y-6">
            <div className="flex items-center gap-4">
                 <Button onClick={() => router.back()} variant="outline" size="icon">
                    <ArrowLeft className="h-4 w-4" />
                    <span className="sr-only">Go Back</span>
                </Button>
                <div>
                    <h1 className="text-3xl font-bold font-headline">{customer.name}</h1>
                    <p className="text-muted-foreground">{customer.phone}</p>
                </div>
            </div>

            <div className="grid gap-4 md:grid-cols-3">
                 <Card>
                    <CardHeader>
                        <CardTitle>Balance</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-2xl font-bold">
                            {new Intl.NumberFormat("en-IN", { style: 'currency', currency: 'INR' }).format(outstandingBalance < 0 ? 0 : outstandingBalance)}
                        </p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle>Total</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-2xl font-bold">
                            {new Intl.NumberFormat("en-IN", { style: 'currency', currency: 'INR' }).format(totalRentalAmount)}
                        </p>
                    </CardContent>
                </Card>
                 <Card>
                    <CardHeader>
                        <CardTitle>Total Orders</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-2xl font-bold">{customerOrders.length}</p>
                    </CardContent>
                </Card>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Record a Payment</CardTitle>
                    <CardDescription>Enter the amount paid by the customer to update their balance.</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="flex items-center gap-2">
                        <div className="relative flex-1">
                            <IndianRupee className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                            <Input 
                                type="number" 
                                placeholder="Enter amount"
                                value={paymentAmount}
                                onChange={(e) => setPaymentAmount(e.target.value)}
                                className="pl-8"
                            />
                        </div>
                        <Button onClick={handleAddPayment}>Add Payment</Button>
                    </div>
                </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                    <CardHeader>
                        <CardTitle>Payment History</CardTitle>
                    </CardHeader>
                    <CardContent className="p-0">
                        {customerPayments.length > 0 ? (
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Date</TableHead>
                                        <TableHead>Amount</TableHead>
                                        <TableHead className="text-right">Action</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {customerPayments.map(payment => (
                                        <TableRow key={payment.id}>
                                            <TableCell>{format(payment.paymentDate, "PPP p")}</TableCell>
                                            <TableCell>{new Intl.NumberFormat("en-IN", { style: 'currency', currency: 'INR' }).format(payment.amount)}</TableCell>
                                            <TableCell className="text-right">
                                                <Button 
                                                    variant="ghost" 
                                                    size="icon" 
                                                    onClick={() => handleDeletePayment(payment)}
                                                    className="text-destructive hover:text-destructive"
                                                >
                                                    <Trash2 className="h-4 w-4" />
                                                </Button>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        ) : (
                            <div className="text-center text-muted-foreground p-8">
                                No payments have been recorded for this customer.
                            </div>
                        )}
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle>Rental History</CardTitle>
                    </CardHeader>
                    <CardContent className="p-0">
                        {customerOrders.length > 0 ? (
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                    <TableHead>Order</TableHead>
                                    <TableHead>Date</TableHead>
                                    <TableHead>Status</TableHead>
                                    <TableHead className="text-right">Amount</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {customerOrders.map(order => (
                                    <TableRow key={order.id} onClick={() => handleViewOrder(order)} className="cursor-pointer">
                                        <TableCell className="font-medium">{order.orderNumber}</TableCell>
                                        <TableCell>{format(order.rentalDate, "PPP")}</TableCell>
                                        <TableCell>
                                            <Badge variant={order.returned ? 'default' : 'secondary'}>{order.returned ? 'Returned' : 'Active'}</Badge>
                                        </TableCell>
                                        <TableCell className="text-right">{new Intl.NumberFormat("en-IN", { style: 'currency', currency: 'INR' }).format(order.rentalAmount)}</TableCell>
                                    </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        ) : (
                            <div className="text-center text-muted-foreground p-8">
                                This customer has no rental history.
                            </div>
                        )}
                    </CardContent>
                </Card>
            </div>

             <AlertDialog open={!!redirectingOrder}>
                <AlertDialogContent>
                <AlertDialogHeader>
                    <AlertDialogTitle>Redirecting...</AlertDialogTitle>
                    <AlertDialogDescription asChild>
                    <div className="flex items-center justify-center p-4">
                        <Loader2 className="mr-2 h-6 w-6 animate-spin" />
                        <div>
                        Taking you to the details for order{" "}
                        <strong>{redirectingOrder?.orderNumber}</strong>.
                        </div>
                    </div>
                    </AlertDialogDescription>
                </AlertDialogHeader>
                </AlertDialogContent>
            </AlertDialog>
        </div>
    );
}
