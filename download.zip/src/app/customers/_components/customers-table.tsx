
"use client";

import * as React from "react";
import type { Customer } from "@/lib/types";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Loader2, MoreHorizontal } from "lucide-react";
import { EditCustomerDialog } from "./edit-customer-dialog";
import { useRouter } from "next/navigation";
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

type CustomerWithTotal = Customer & { totalAmount?: number };

type CustomersTableProps = {
  data: CustomerWithTotal[];
  onUpdateCustomer: (customerId: string, updatedCustomer: Omit<Customer, "id" | "rentalHistory" | "outstandingBalance">) => void;
  onDeleteCustomer: (customerId: string) => void;
};

export default function CustomersTable({ data, onUpdateCustomer, onDeleteCustomer }: CustomersTableProps) {
  const router = useRouter();
  const [redirectingCustomer, setRedirectingCustomer] = React.useState<Customer | null>(null);

  const handleViewHistory = (customer: Customer) => {
    setRedirectingCustomer(customer);
    setTimeout(() => {
      router.push(`/customers/${customer.id}`);
    }, 1000); 
  };


  return (
    <div className="rounded-lg">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="font-headline">Name</TableHead>
            <TableHead className="font-headline">Phone Number</TableHead>
            <TableHead className="text-right font-headline">
              Total Amount (INR)
            </TableHead>
            <TableHead className="text-right font-headline">
              Balance (INR)
            </TableHead>
            <TableHead>
              <span className="sr-only">Actions</span>
            </TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.map((customer) => (
            <TableRow key={customer.id} onClick={() => handleViewHistory(customer)} className="cursor-pointer">
              <TableCell className="font-medium">{customer.name}</TableCell>
              <TableCell>
                <div className="font-medium">{customer.phone}</div>
              </TableCell>
              <TableCell className="text-right">
                {customer.totalAmount ? new Intl.NumberFormat("en-IN").format(
                  customer.totalAmount
                ) : '-'}
              </TableCell>
              <TableCell className="text-right">
                {customer.outstandingBalance > 0 ? new Intl.NumberFormat("en-IN").format(
                  customer.outstandingBalance
                ) : '-'}
              </TableCell>
              <TableCell className="text-right" onClick={(e) => e.stopPropagation()}>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="h-8 w-8 p-0">
                      <span className="sr-only">Open menu</span>
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuLabel>Actions</DropdownMenuLabel>
                    <EditCustomerDialog customer={customer} onUpdateCustomer={onUpdateCustomer} />
                    <DropdownMenuItem onClick={() => handleViewHistory(customer)}>
                        View Rental History
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem
                      className="text-destructive"
                      onClick={() => onDeleteCustomer(customer.id)}
                    >
                      Delete Customer
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
       <AlertDialog open={!!redirectingCustomer}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Redirecting...</AlertDialogTitle>
            <AlertDialogDescription asChild>
              <div className="flex items-center justify-center p-4">
                <Loader2 className="mr-2 h-6 w-6 animate-spin" />
                <div>
                  Taking you to the rental history for{" "}
                  <strong>{redirectingCustomer?.name}</strong>.
                </div>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
