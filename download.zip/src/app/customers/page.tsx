
"use client";

import * as React from "react";
import { useLocalStorage } from "@/hooks/use-local-storage";
import type { Customer, Order, Payment } from "@/lib/types";
import { Card, CardContent } from "@/components/ui/card";
import CustomersTable from "./_components/customers-table";
import { AddCustomerDialog } from "./_components/add-customer-dialog";

export default function CustomersPage() {
  const [customers, setCustomers] = useLocalStorage<Customer[]>("customers", []);
  const [orders] = useLocalStorage<Order[]>("orders", []);
  const [payments] = useLocalStorage<Payment[]>("payments", []);

  const addCustomer = (newCustomer: Omit<Customer, "id" | "rentalHistory" | "outstandingBalance">) => {
    setCustomers((prev) => [
      ...prev,
      {
        id: `c${Date.now()}`,
        rentalHistory: [],
        outstandingBalance: 0,
        ...newCustomer,
      },
    ]);
  };

  const updateCustomer = (customerId: string, updatedCustomer: Omit<Customer, "id" | "rentalHistory" | "outstandingBalance">) => {
    setCustomers((prevCustomers) =>
      prevCustomers.map((customer) =>
        customer.id === customerId ? { ...customer, ...updatedCustomer } : customer
      )
    );
  };

  const deleteCustomer = (customerId: string) => {
    setCustomers((prevCustomers) =>
      prevCustomers.filter((customer) => customer.id !== customerId)
    );
  };

  const customersWithDetails = customers.map(customer => {
    const customerOrders = orders.filter(order => order.customerId === customer.id);
    const totalAmount = customerOrders.reduce((acc, order) => acc + order.rentalAmount, 0);
    const customerPayments = payments.filter(p => p.customerId === customer.id);
    const totalPaid = customerPayments.reduce((acc, payment) => acc + payment.amount, 0);
    const outstandingBalance = totalAmount - totalPaid;
    return { ...customer, totalAmount, outstandingBalance };
  });


  return (
    <div className="space-y-6">
      <div className="flex items-center justify-end">
        <AddCustomerDialog onAddCustomer={addCustomer} />
      </div>
      <Card>
        <CardContent className="p-0">
            <CustomersTable data={customersWithDetails} onUpdateCustomer={updateCustomer} onDeleteCustomer={deleteCustomer} />
        </CardContent>
      </Card>
    </div>
  );
}
