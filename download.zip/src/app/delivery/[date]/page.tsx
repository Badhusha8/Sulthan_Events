
"use client";

import * as React from "react";
import { useParams, useRouter } from 'next/navigation';
import { useLocalStorage } from "@/hooks/use-local-storage";
import type { Order, Customer, Plate } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { format, parseISO, startOfDay, subDays, isSameDay } from "date-fns";
import { UtensilsCrossed, Calendar, MapPin, User, Phone, Clock, ArrowLeft, Package, PackageOpen, History } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CreateOrderDialog } from "@/app/orders/_components/create-order-dialog";

export default function DeliveryDetailsPage() {
    const router = useRouter();
    const params = useParams();
    const date = params.date as string;
    const selectedDate = startOfDay(parseISO(date));

    const [orders, setOrders] = useLocalStorage<Order[]>("orders", []);
    const [customers] = useLocalStorage<Customer[]>("customers", []);
    const [plates] = useLocalStorage<Plate[]>("plates", []);

    const addOrder = (newOrder: Omit<Order, "id" | "orderNumber" | "returned" | "paymentStatus">) => {
        const maxOrderNumber = orders.reduce((max, order) => {
            const currentNum = parseInt(order.orderNumber.replace(/[^0-9]/g, ''), 10);
            return currentNum > max ? currentNum : max;
        }, 0);
        const newOrderNumber = maxOrderNumber + 1;
    
        const orderToAdd: Order = {
            ...newOrder,
            id: `o${Date.now()}`,
            orderNumber: `##${String(newOrderNumber).padStart(4, '0')}`,
            returned: false,
            paymentStatus: 'Pending',
        };
    
        setOrders((prev) => [orderToAdd, ...prev]);
      };

    const deliveriesForDate = orders
        .filter(order => {
            const orderDate = startOfDay(new Date(order.rentalDate));
            return orderDate.getTime() === selectedDate.getTime() && !order.returned;
        })
        .map((order) => ({
            ...order,
            customer: customers.find((c) => c.id === order.customerId),
            items: order.items.map((item) => ({
                ...item,
                plateName: plates.find((p) => p.id === item.plateId)?.name || "Unknown Plate",
            })),
            rentalDate: new Date(order.rentalDate),
        }))
        .sort((a, b) => a.rentalDate.getTime() - b.rentalDate.getTime());
    
    const pickupsForDate = orders
        .filter(order => {
            if (order.returned) return false;
            const returnDate = order.returnDate ? startOfDay(new Date(order.returnDate)) : subDays(startOfDay(new Date(order.rentalDate)), -1);
            return isSameDay(returnDate, selectedDate);
        })
        .map((order) => ({
            ...order,
            customer: customers.find((c) => c.id === order.customerId),
            items: order.items.map((item) => ({
                ...item,
                plateName: plates.find((p) => p.id === item.plateId)?.name || "Unknown Plate",
            })),
            rentalDate: new Date(order.rentalDate),
        }))
        .sort((a, b) => a.rentalDate.getTime() - b.rentalDate.getTime());

    const historyForDate = orders
        .filter(order => {
            const orderRentalDate = startOfDay(new Date(order.rentalDate));
            const orderReturnDate = order.returnDate ? startOfDay(new Date(order.returnDate)) : null;

            return (order.returned && isSameDay(orderRentalDate, selectedDate)) || (orderReturnDate && isSameDay(orderReturnDate, selectedDate));
        })
        .map(order => ({
            ...order,
            customer: customers.find(c => c.id === order.customerId),
            activityType: isSameDay(startOfDay(new Date(order.rentalDate)), selectedDate) ? 'Delivered' : 'Picked Up',
            totalPlates: order.items.reduce((sum, item) => sum + item.quantity, 0)
        }))
        .sort((a, b) => new Date(b.rentalDate).getTime() - new Date(b.rentalDate).getTime());

        
    const totalPlatesOnDate = deliveriesForDate.reduce((sum, delivery) => 
        sum + delivery.items.reduce((itemSum, item) => itemSum + item.quantity, 0)
    , 0);

    const totalPlatesInStock = plates.reduce((sum, plate) => sum + plate.quantity, 0);
    const availablePlates = totalPlatesInStock - totalPlatesOnDate;


    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                    <Button onClick={() => router.push('/')} variant="outline" size="icon">
                        <ArrowLeft className="h-4 w-4" />
                        <span className="sr-only">Back to Calendar</span>
                    </Button>
                    <h1 className="text-2xl font-bold font-headline">
                        Schedule for {format(selectedDate, "PPP")}
                    </h1>
                </div>
                <div className="flex items-center gap-2">
                     <Card className="w-fit">
                        <CardHeader className="p-3">
                            <CardDescription>Available</CardDescription>
                             <CardTitle className="text-3xl">{availablePlates}</CardTitle>
                        </CardHeader>
                    </Card>
                    <CreateOrderDialog customers={customers} plates={plates} onAddOrder={addOrder} rentalDate={selectedDate} />
                </div>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="space-y-4">
                    <h2 className="text-xl font-bold font-headline flex items-center gap-2">
                        <Package className="text-accent" />
                        Deliveries ({deliveriesForDate.length})
                    </h2>
                     {deliveriesForDate.length > 0 ? (
                        <div className="grid gap-4">
                            {deliveriesForDate.map((delivery) => (
                                <Card key={delivery.id}>
                                    <CardHeader>
                                        <CardTitle className="flex justify-between items-center">
                                            <div className="flex items-center gap-4">
                                                <span onClick={() => router.push(`/orders/${delivery.id}`)} className="cursor-pointer hover:underline">Order {delivery.orderNumber}</span>
                                                <span className="text-base font-bold bg-secondary text-secondary-foreground px-2 py-1 rounded-md">({delivery.items.reduce((sum, i) => sum + i.quantity, 0)} plates)</span>
                                            </div>
                                            <div className="text-sm font-semibold bg-secondary/80 text-secondary-foreground px-2 py-1 rounded-md flex items-center gap-2">
                                                <Clock className="h-4 w-4" /> {delivery.session}
                                            </div>
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-4">
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                                            <div className="space-y-2">
                                                <div className="flex items-center gap-2">
                                                    <User className="h-4 w-4 text-muted-foreground"/>
                                                    <span onClick={() => router.push(`/customers/${delivery.customer?.id}`)} className="font-semibold cursor-pointer hover:underline">{delivery.customer?.name || "N/A"}</span>
                                                </div>
                                                <div className="flex items-center gap-2">
                                                    <Phone className="h-4 w-4 text-muted-foreground"/>
                                                    <span>{delivery.customer?.phone || "N/A"}</span>
                                                </div>
                                            </div>
                                            <div className="space-y-2">
                                                    <div className="flex items-center gap-2">
                                                    <MapPin className="h-4 w-4 text-muted-foreground"/>
                                                    <span className="font-semibold">{delivery.auditorium || "N/A"}</span>
                                                </div>
                                                <div className="flex items-center gap-2">
                                                    <Calendar className="h-4 w-4 text-muted-foreground"/>
                                                    <span>{format(delivery.rentalDate, "PPP")}</span>
                                                </div>
                                            </div>
                                        </div>

                                        <Accordion type="single" collapsible>
                                            <AccordionItem value="items">
                                                <AccordionTrigger>
                                                    <div className="flex items-center gap-2">
                                                        <UtensilsCrossed className="h-4 w-4 text-muted-foreground" />
                                                        <span>
                                                            View Items ({delivery.items.reduce((sum, i) => sum + i.quantity, 0)} total plates)
                                                        </span>
                                                    </div>
                                                </AccordionTrigger>
                                                <AccordionContent>
                                                    <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
                                                        {delivery.items.map(item => (
                                                            <li key={item.plateId}>
                                                                {item.plateName} - <strong>{item.quantity}</strong> pcs
                                                            </li>
                                                        ))}
                                                    </ul>
                                                </AccordionContent>
                                            </AccordionItem>
                                        </Accordion>
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    ) : (
                        <div className="flex flex-col items-center justify-center h-48 border-dashed border-2 rounded-lg">
                            <p className="text-muted-foreground">No deliveries scheduled for this date.</p>
                        </div>
                    )}
                </div>
                 <div className="space-y-4">
                     <h2 className="text-xl font-bold font-headline flex items-center gap-2">
                        <PackageOpen className="text-accent" />
                        Pickups ({pickupsForDate.length})
                    </h2>
                     {pickupsForDate.length > 0 ? (
                        <div className="grid gap-4">
                            {pickupsForDate.map((pickup) => (
                                <Card key={pickup.id}>
                                    <CardHeader>
                                        <CardTitle className="flex justify-between items-center">
                                            <div className="flex items-center gap-4">
                                                <span onClick={() => router.push(`/orders/${pickup.id}`)} className="cursor-pointer hover:underline">Order {pickup.orderNumber}</span>
                                                <span className="text-base font-bold bg-secondary text-secondary-foreground px-2 py-1 rounded-md">({pickup.items.reduce((sum, i) => sum + i.quantity, 0)} plates)</span>
                                            </div>
                                            <div className="text-sm font-semibold bg-secondary/80 text-secondary-foreground px-2 py-1 rounded-md flex items-center gap-2">
                                                <Clock className="h-4 w-4" /> {pickup.session}
                                            </div>
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-4">
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                                            <div className="space-y-2">
                                                <div className="flex items-center gap-2">
                                                    <User className="h-4 w-4 text-muted-foreground"/>
                                                    <span onClick={() => router.push(`/customers/${pickup.customer?.id}`)} className="font-semibold cursor-pointer hover:underline">{pickup.customer?.name || "N/A"}</span>
                                                </div>
                                                <div className="flex items-center gap-2">
                                                    <Phone className="h-4 w-4 text-muted-foreground"/>
                                                    <span>{pickup.customer?.phone || "N/A"}</span>
                                                </div>
                                            </div>
                                            <div className="space-y-2">
                                                <div className="flex items-center gap-2">
                                                    <MapPin className="h-4 w-4 text-muted-foreground"/>
                                                    <span className="font-semibold">{pickup.auditorium || "N/A"}</span>
                                                </div>
                                                <div className="flex items-center gap-2">
                                                    <Calendar className="h-4 w-4 text-muted-foreground"/>
                                                    <span>Rented: {format(pickup.rentalDate, "PPP")}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    ) : (
                        <div className="flex flex-col items-center justify-center h-48 border-dashed border-2 rounded-lg">
                            <p className="text-muted-foreground">No pickups scheduled for this date.</p>
                        </div>
                    )}
                </div>
                <div className="space-y-4">
                    <h2 className="text-xl font-bold font-headline flex items-center gap-2">
                        <History className="text-accent" />
                        History ({historyForDate.length})
                    </h2>
                    {historyForDate.length > 0 ? (
                        <div className="grid gap-4">
                            {historyForDate.map((order) => (
                                <Card key={order.id} className="bg-muted/50">
                                    <CardHeader>
                                        <CardTitle className="flex justify-between items-center text-base">
                                            <span onClick={() => router.push(`/orders/${order.id}`)} className="cursor-pointer hover:underline">
                                                Order {order.orderNumber}
                                            </span>
                                            <span className={`text-xs font-semibold px-2 py-1 rounded-md ${order.activityType === 'Delivered' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'}`}>
                                                {order.activityType} on this day
                                            </span>
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent className="text-sm space-y-2">
                                        <div className="flex items-center gap-2">
                                            <User className="h-4 w-4 text-muted-foreground"/>
                                            <span onClick={() => router.push(`/customers/${order.customer?.id}`)} className="font-semibold cursor-pointer hover:underline">
                                                {order.customer?.name || "N/A"}
                                            </span>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <UtensilsCrossed className="h-4 w-4 text-muted-foreground"/>
                                            <span>{order.totalPlates} plates</span>
                                        </div>
                                        {order.returnDate && (
                                            <div className="flex items-center gap-2 text-muted-foreground">
                                                <Calendar className="h-4 w-4" />
                                                <span>Returned: {format(new Date(order.returnDate), "PPP")}</span>
                                            </div>
                                        )}
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    ) : (
                         <div className="flex flex-col items-center justify-center h-48 border-dashed border-2 rounded-lg">
                            <p className="text-muted-foreground">No historical activity for this date.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

    

    