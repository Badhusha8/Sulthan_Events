
"use client";

import * as React from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { PlusCircle } from "lucide-react";
import type { Plate } from "@/lib/types";

const formSchema = z.object({
  name: z.string().min(1, "Name is required"),
  quantity: z.coerce.number().int().positive("Quantity must be a positive number"),
  ratePerPiece: z.coerce.number().positive("Rate must be a positive number"),
});

type AddPlateFormValues = z.infer<typeof formSchema>;

type AddPlateDialogProps = {
  onAddPlate: (newPlate: Omit<Plate, "id" | "damaged">) => void;
};

export function AddPlateDialog({ onAddPlate }: AddPlateDialogProps) {
  const [open, setOpen] = React.useState(false);
  const form = useForm<AddPlateFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      quantity: 0,
      ratePerPiece: 0,
    },
  });

  const onSubmit = (values: AddPlateFormValues) => {
    onAddPlate(values);
    form.reset();
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="font-headline bg-primary hover:bg-primary/90 text-primary-foreground">
          <PlusCircle className="mr-2 h-4 w-4" />
          Add New Plate
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add New Plate</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Name</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. 10 inch Dinner Plate" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="quantity"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Quantity</FormLabel>
                  <FormControl>
                    <Input type="number" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="ratePerPiece"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Rate per Piece (INR)</FormLabel>
                  <FormControl>
                    <Input type="number" step="0.01" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="flex justify-end">
              <Button type="submit">Add Plate</Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
