
"use client";

import * as React from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import type { Plate } from "@/lib/types";
import { DropdownMenuItem } from "@/components/ui/dropdown-menu";

const formSchema = z.object({
  name: z.string().min(1, "Name is required"),
  quantity: z.coerce.number().int().nonnegative("Quantity must be a non-negative number"),
  damaged: z.coerce.number().int().nonnegative("Damaged count must be a non-negative number"),
  ratePerPiece: z.coerce.number().positive("Rate must be a positive number"),
});

type EditPlateFormValues = z.infer<typeof formSchema>;

type EditPlateDialogProps = {
  plate: Plate;
  onUpdatePlate: (plateId: string, updatedPlate: Omit<Plate, "id">) => void;
};

export function EditPlateDialog({ plate, onUpdatePlate }: EditPlateDialogProps) {
  const [open, setOpen] = React.useState(false);
  const form = useForm<EditPlateFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: plate.name,
      quantity: plate.quantity,
      damaged: plate.damaged,
      ratePerPiece: plate.ratePerPiece,
    },
  });

  const onSubmit = (values: EditPlateFormValues) => {
    onUpdatePlate(plate.id, values);
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
          Edit
        </DropdownMenuItem>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Edit Plate</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Name</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. 10 inch Dinner Plate" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="quantity"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Quantity</FormLabel>
                  <FormControl>
                    <Input type="number" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="damaged"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Damaged</FormLabel>
                  <FormControl>
                    <Input type="number" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="ratePerPiece"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Rate per Piece (INR)</FormLabel>
                  <FormControl>
                    <Input type="number" step="0.01" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="flex justify-end">
              <Button type="submit">Save Changes</Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
