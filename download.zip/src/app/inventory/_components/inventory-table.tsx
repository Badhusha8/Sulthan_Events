
"use client";

import * as React from "react";
import type { Plate } from "@/lib/types";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { MoreHorizontal } from "lucide-react";
import { EditPlateDialog } from "./edit-plate-dialog";

type InventoryTableProps = {
  data: Plate[];
  onUpdatePlate: (plateId: string, updatedPlate: Omit<Plate, 'id'>) => void;
  onDeletePlate: (plateId: string) => void;
};

export default function InventoryTable({
  data,
  onUpdatePlate,
  onDeletePlate,
}: InventoryTableProps) {
  return (
    <div className="rounded-lg">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="font-headline">Name</TableHead>
            <TableHead className="text-center font-headline">
              Quantity
            </TableHead>
            <TableHead className="text-center font-headline">
              Damaged
            </TableHead>
            <TableHead className="text-right font-headline">
              Rate per Piece (INR)
            </TableHead>
            <TableHead>
              <span className="sr-only">Actions</span>
            </TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.length > 0 ? (
            data.map((plate) => (
              <TableRow key={plate.id}>
                <TableCell className="font-medium">{plate.name}</TableCell>
                <TableCell className="text-center">{plate.quantity}</TableCell>
                <TableCell className="text-center">{plate.damaged}</TableCell>
                <TableCell className="text-right">
                  {new Intl.NumberFormat("en-IN").format(plate.ratePerPiece)}
                </TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="h-8 w-8 p-0">
                        <span className="sr-only">Open menu</span>
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                      <EditPlateDialog plate={plate} onUpdatePlate={onUpdatePlate} />
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        className="text-destructive"
                        onClick={() => onDeletePlate(plate.id)}
                      >
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell
                colSpan={5}
                className="h-24 text-center text-muted-foreground"
              >
                No plates found.
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
}
