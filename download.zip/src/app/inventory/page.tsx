
"use client";

import * as React from "react";
import InventoryTable from "./_components/inventory-table";
import type { Plate } from "@/lib/types";
import { Card, CardContent } from "@/components/ui/card";
import { AddPlateDialog } from "./_components/add-plate-dialog";
import { useLocalStorage } from "@/hooks/use-local-storage";

export default function InventoryPage() {
  const [plates, setPlates] = useLocalStorage<Plate[]>("plates", []);

  const addPlate = (newPlate: Omit<Plate, "id" | "damaged">) => {
    setPlates((prevPlates) => [
      ...prevPlates,
      {
        id: `p${Date.now()}`,
        damaged: 0,
        ...newPlate,
      },
    ]);
  };

  const updatePlate = (plateId: string, updatedPlate: Omit<Plate, "id">) => {
    setPlates((prevPlates) =>
      prevPlates.map((plate) =>
        plate.id === plateId ? { ...plate, ...updatedPlate } : plate
      )
    );
  };

  const deletePlate = (plateId: string) => {
    setPlates((prevPlates) =>
      prevPlates.filter((plate) => plate.id !== plateId)
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-end">
        <AddPlateDialog onAddPlate={addPlate} />
      </div>
      <Card>
        <CardContent className="p-0">
          <InventoryTable data={plates} onUpdatePlate={updatePlate} onDeletePlate={deletePlate} />
        </CardContent>
      </Card>
    </div>
  );
}
