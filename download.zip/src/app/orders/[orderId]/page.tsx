
"use client";

import * as React from "react";
import { useParams, useRouter } from 'next/navigation';
import { useLocalStorage } from "@/hooks/use-local-storage";
import type { Order, Customer, Plate } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, UtensilsCrossed, Calendar, MapPin, User, Phone, Clock, IndianRupee, CheckCircle2, Loader2, AlertTriangle } from "lucide-react";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
  } from "@/components/ui/table";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { ReturnOrderDialog } from "../_components/return-order-dialog";


export default function OrderDetailsPage() {
    const router = useRouter();
    const params = useParams();
    const { toast } = useToast();
    const orderId = params.orderId as string;
    const [isClient, setIsClient] = React.useState(false);

    React.useEffect(() => {
        setIsClient(true);
    }, []);

    const [orders, setOrders] = useLocalStorage<Order[]>("orders", []);
    const [customers] = useLocalStorage<Customer[]>("customers", []);
    const [plates, setPlates] = useLocalStorage<Plate[]>("plates", []);

    const order = orders.find((o) => o.id === orderId);

    const orderWithDetails = React.useMemo(() => {
        if (!order) return null;
        return {
            ...order,
            customer: customers.find((c) => c.id === order.customerId),
            items: order.items.map((item) => {
                const plate = plates.find((p) => p.id === item.plateId);
                return {
                    ...item,
                    plateName: plate?.name || "Unknown",
                    ratePerPiece: plate?.ratePerPiece || item.ratePerPiece,
                }
            }),
            rentalDate: new Date(order.rentalDate),
        }
    }, [order, customers, plates]);

    if (!isClient) {
        return (
             <div className="flex items-center justify-center h-full">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
        );
    }

    if (!orderWithDetails) {
        return (
            <div className="flex flex-col items-center justify-center h-full text-center">
                <p className="text-lg text-muted-foreground">Order not found.</p>
                <Button onClick={() => router.back()} className="mt-4">
                    <ArrowLeft className="mr-2 h-4 w-4" /> Go Back
                </Button>
            </div>
        )
    }

    const { customer, items, rentalDate, session, auditorium, orderNumber, returned, rentalAmount, damageFee } = orderWithDetails;
    const totalAmount = rentalAmount;

    return (
        <div className="space-y-6">
            <div className="flex items-center gap-4">
                 <Button onClick={() => router.back()} variant="outline" size="icon">
                    <ArrowLeft className="h-4 w-4" />
                    <span className="sr-only">Go Back</span>
                </Button>
                <div>
                    <h1 className="text-3xl font-bold font-headline">Order {orderNumber}</h1>
                    <p className="text-muted-foreground">Details for order placed on {format(rentalDate, "PPP")}</p>
                </div>
            </div>
            
            <Card>
                <CardHeader>
                    <CardTitle>Order Status</CardTitle>
                    <CardDescription>Manage the return status of this order.</CardDescription>
                </CardHeader>
                <CardContent>
                    {returned ? (
                        <div className="flex items-center gap-2 p-4 bg-secondary rounded-lg">
                            <CheckCircle2 className="h-6 w-6 text-green-600" />
                            <div>
                                <p className="font-semibold">This order has been marked as returned.</p>
                                {orderWithDetails.returnDate && <p className="text-sm text-muted-foreground">Returned on: {format(new Date(orderWithDetails.returnDate), "PPP p")}</p>}
                            </div>
                        </div>
                    ) : (
                       <ReturnOrderDialog order={orderWithDetails} plates={plates} setOrders={setOrders} setPlates={setPlates} />
                    )}
                </CardContent>
            </Card>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-base">
                            <User className="text-accent" />
                            Customer Details
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2 text-sm">
                        <p className="font-semibold text-lg">{customer?.name}</p>
                        <div className="flex items-center gap-2 text-muted-foreground">
                            <Phone className="h-4 w-4"/>
                            <span>{customer?.phone}</span>
                        </div>
                    </CardContent>
                </Card>
                 <Card>
                    <CardHeader>
                         <CardTitle className="flex items-center gap-2 text-base">
                            <MapPin className="text-accent" />
                            Venue & Time
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2 text-sm">
                        <p className="font-semibold text-lg">{auditorium}</p>
                        <div className="flex items-center gap-2 text-muted-foreground">
                            <Clock className="h-4 w-4"/>
                            <span>{session} Session</span>
                        </div>
                    </CardContent>
                </Card>
                 <Card>
                    <CardHeader>
                         <CardTitle className="flex items-center gap-2 text-base">
                            <IndianRupee className="text-accent" />
                            Total Amount
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                         <p className="text-2xl font-bold">
                            {new Intl.NumberFormat("en-IN", { style: 'currency', currency: 'INR' }).format(totalAmount)}
                        </p>
                        <p className="text-xs text-muted-foreground">
                            Rental: {new Intl.NumberFormat("en-IN", { style: 'currency', currency: 'INR' }).format(rentalAmount - (damageFee || 0))}
                            {damageFee && ` + Damage: ${new Intl.NumberFormat("en-IN", { style: 'currency', currency: 'INR' }).format(damageFee)}`}
                        </p>
                    </CardContent>
                </Card>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <UtensilsCrossed className="text-accent"/>
                        Items in Order
                    </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                    <Table>
                        <TableHeader>
                            <TableRow>
                            <TableHead>Item</TableHead>
                            <TableHead className="text-center">Quantity</TableHead>
                            <TableHead className="text-right">Rate</TableHead>
                            <TableHead className="text-right">Subtotal</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {items.map(item => (
                            <TableRow key={item.plateId}>
                                <TableCell className="font-medium">{item.plateName}</TableCell>
                                <TableCell className="text-center">{item.quantity}</TableCell>
                                <TableCell className="text-right">{new Intl.NumberFormat("en-IN", { style: 'currency', currency: 'INR' }).format(item.ratePerPiece)}</TableCell>
                                <TableCell className="text-right">{new Intl.NumberFormat("en-IN", { style: 'currency', currency: 'INR' }).format(item.quantity * item.ratePerPiece)}</TableCell>
                            </TableRow>
                            ))}
                             {damageFee && damageFee > 0 && (
                                <TableRow className="bg-destructive/10 hover:bg-destructive/15">
                                    <TableCell colSpan={3} className="font-semibold text-destructive">
                                        <div className="flex items-center gap-2">
                                            <AlertTriangle className="h-4 w-4" />
                                            <span>Damaged Plates Fee</span>
                                        </div>
                                    </TableCell>
                                    <TableCell className="text-right font-bold text-destructive">
                                        {new Intl.NumberFormat("en-IN", { style: 'currency', currency: 'INR' }).format(damageFee)}
                                    </TableCell>
                                </TableRow>
                            )}
                            <TableRow className="bg-secondary/80 hover:bg-secondary">
                                <TableCell colSpan={3} className="font-bold">Total Amount</TableCell>
                                <TableCell className="text-right font-bold">
                                    {new Intl.NumberFormat("en-IN", { style: 'currency', currency: 'INR' }).format(totalAmount)}
                                </TableCell>
                            </TableRow>
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </div>
    );
}

    