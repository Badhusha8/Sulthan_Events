
"use client";

import * as React from "react";
import { z } from "zod";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { PlusCircle, Trash2, CalendarIcon } from "lucide-react";
import type { Customer, Plate, Order } from "@/lib/types";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

const formSchema = z.object({
  customerId: z.string().min(1, "Customer is required"),
  items: z.array(z.object({
    plateId: z.string().min(1, "Plate is required"),
    quantity: z.coerce.number().int().positive("Quantity must be a positive number"),
    ratePerPiece: z.coerce.number().positive("Rate must be a positive number"),
  })).min(1, "At least one item is required"),
  rentalDate: z.date({ required_error: "Rental date is required" }),
  session: z.enum(["Morning", "Noon", "Evening"]),
  auditorium: z.string().min(1, "Auditorium is required"),
});

type CreateOrderFormValues = z.infer<typeof formSchema>;

type CreateOrderDialogProps = {
  customers: Customer[];
  plates: Plate[];
  onAddOrder: (newOrder: Omit<Order, "id" | "orderNumber" | "returned" | "paymentStatus">) => void;
  rentalDate?: Date;
};

export function CreateOrderDialog({ customers, plates, onAddOrder, rentalDate }: CreateOrderDialogProps) {
  const [open, setOpen] = React.useState(false);
  const form = useForm<CreateOrderFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      customerId: "",
      items: [],
      auditorium: "",
      session: "Morning",
      rentalDate: rentalDate || undefined,
    },
  });

  React.useEffect(() => {
    if (rentalDate) {
      form.setValue("rentalDate", rentalDate);
    }
  }, [rentalDate, form, open]);


  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "items",
  });

  const watchedItems = form.watch("items");


  const onSubmit = (values: CreateOrderFormValues) => {
    const rentalAmount = watchedItems.reduce((acc, item) => {
        return acc + (item.quantity || 0) * (item.ratePerPiece || 0);
      }, 0);
    onAddOrder({...values, rentalAmount});
    form.reset({
        customerId: "",
        items: [],
        auditorium: "",
        session: "Morning",
        rentalDate: rentalDate || undefined,
    });
    setOpen(false);
  };
  
  const selectedPlateIds = form.watch('items').map(item => item.plateId);
  
  const handlePlateChange = (plateId: string, index: number) => {
    const plate = plates.find(p => p.id === plateId);
    if (plate) {
      form.setValue(`items.${index}.ratePerPiece`, plate.ratePerPiece);
      form.setValue(`items.${index}.plateId`, plate.id);
    }
  };

  const handleAddNewItem = () => {
    const firstAvailablePlate = plates.find(p => !selectedPlateIds.includes(p.id));
    if (firstAvailablePlate) {
        append({ plateId: firstAvailablePlate.id, quantity: 1, ratePerPiece: firstAvailablePlate.ratePerPiece });
    } else {
        // Or handle case where no plates are available
        append({ plateId: "", quantity: 1, ratePerPiece: 0 });
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="font-headline bg-primary hover:bg-primary/90 text-primary-foreground">
          <PlusCircle className="mr-2 h-4 w-4" />
          Create New Order
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle>Create New Order</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="customerId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Customer</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a customer" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {customers.map(customer => (
                        <SelectItem key={customer.id} value={customer.id}>
                          {customer.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div>
              <FormLabel>Items</FormLabel>
              <div className="space-y-2 mt-2">
                {fields.map((field, index) => (
                  <div key={field.id} className="grid grid-cols-[2fr_1fr_1fr_auto] items-end gap-2">
                    <FormField
                      control={form.control}
                      name={`items.${index}.plateId`}
                      render={({ field: formField }) => (
                        <FormItem>
                          <Select onValueChange={(value) => handlePlateChange(value, index)} value={formField.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select a plate" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                                {plates.map(plate => (
                                <SelectItem key={plate.id} value={plate.id} disabled={selectedPlateIds.includes(plate.id) && plate.id !== formField.value}>
                                    {plate.name}
                                </SelectItem>
                                ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name={`items.${index}.quantity`}
                      render={({ field }) => (
                        <FormItem>
                           {index === 0 && <FormLabel>Quantity</FormLabel>}
                          <FormControl>
                            <Input type="number" placeholder="Qty" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name={`items.${index}.ratePerPiece`}
                      render={({ field }) => (
                        <FormItem>
                           {index === 0 && <FormLabel>Rate</FormLabel>}
                          <FormControl>
                            <Input type="number" step="0.01" placeholder="Rate" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button type="button" variant="destructive" size="icon" onClick={() => remove(index)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
              <Button type="button" variant="outline" size="sm" className="mt-2" onClick={handleAddNewItem}>
                <PlusCircle className="mr-2 h-4 w-4" /> Add Item
              </Button>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
                 <FormField
                    control={form.control}
                    name="rentalDate"
                    render={({ field }) => (
                        <FormItem className="flex flex-col">
                        <FormLabel>Rental Date</FormLabel>
                        <Popover>
                            <PopoverTrigger asChild>
                            <FormControl>
                                <Button
                                variant={"outline"}
                                className={cn(
                                    "w-full pl-3 text-left font-normal",
                                    !field.value && "text-muted-foreground"
                                )}
                                >
                                {field.value ? (
                                    format(field.value, "PPP")
                                ) : (
                                    <span>Pick a date</span>
                                )}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                            </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                                mode="single"
                                selected={field.value}
                                onSelect={field.onChange}
                                disabled={(date) => date < new Date(new Date().setHours(0,0,0,0))}
                                initialFocus
                            />
                            </PopoverContent>
                        </Popover>
                        <FormMessage />
                        </FormItem>
                    )}
                 />
                 <FormField
                    control={form.control}
                    name="session"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Session</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                            <SelectTrigger>
                                <SelectValue placeholder="Select a session" />
                            </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                                <SelectItem value="Morning">Morning</SelectItem>
                                <SelectItem value="Noon">Noon</SelectItem>
                                <SelectItem value="Evening">Evening</SelectItem>
                            </SelectContent>
                        </Select>
                        <FormMessage />
                        </FormItem>
                    )}
                    />
            </div>
             <FormField
              control={form.control}
              name="auditorium"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Auditorium / Venue</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. SKM Hall, Erode" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button type="submit">Create Order</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
