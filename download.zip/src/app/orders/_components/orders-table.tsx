
"use client";

import * as React from "react";
import type { Customer, Order, Plate } from "@/lib/types";
import { format } from "date-fns";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Loader2, MoreHorizontal } from "lucide-react";
import { EditOrderDialog } from "./edit-order-dialog";
import { useRouter } from "next/navigation";
import {
    AlertDialog,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogHeader,
    AlertDialogTitle,
  } from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";

type OrdersTableProps = {
  data: (Order & {
    customerName: string;
    items: { plateName: string; quantity: number }[];
  })[];
  customers: Customer[];
  plates: Plate[];
  onUpdateOrder: (orderId: string, updatedOrder: Partial<Omit<Order, "id">>) => void;
  onDeleteOrder: (orderId: string) => void;
};

export default function OrdersTable({ data, customers, plates, onUpdateOrder, onDeleteOrder }: OrdersTableProps) {
  const router = useRouter();
  const [redirectingOrder, setRedirectingOrder] = React.useState<Order | null>(null);

  const handleViewDetails = (order: Order) => {
    setRedirectingOrder(order);
    setTimeout(() => {
      router.push(`/orders/${order.id}`);
    }, 1000); 
  };
  
  return (
    <div className="rounded-lg">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="font-headline">Customer</TableHead>
            <TableHead className="font-headline">Plates</TableHead>
            <TableHead className="font-headline">Rental Date</TableHead>
            <TableHead className="font-headline">Status</TableHead>
            <TableHead className="font-headline">Venue</TableHead>
            <TableHead>
              <span className="sr-only">Actions</span>
            </TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.map((order) => (
            <TableRow key={order.id} onClick={() => handleViewDetails(order)} className="cursor-pointer">
              <TableCell>{order.customerName}</TableCell>
              <TableCell className="text-center">{order.items.reduce((acc, item) => acc + item.quantity, 0)}</TableCell>
              <TableCell>
                {format(new Date(order.rentalDate), "PPP")}
              </TableCell>
               <TableCell>
                <Badge variant={order.returned ? 'default' : 'secondary'}>{order.returned ? 'Returned' : 'Active'}</Badge>
              </TableCell>
              <TableCell>{order.auditorium}</TableCell>
              <TableCell className="text-right" onClick={(e) => e.stopPropagation()}>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="h-8 w-8 p-0">
                      <span className="sr-only">Open menu</span>
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuLabel>Actions</DropdownMenuLabel>
                    <DropdownMenuItem onClick={() => handleViewDetails(order)}>
                        View Order Details
                    </DropdownMenuItem>
                    <EditOrderDialog 
                        order={order} 
                        customers={customers} 
                        plates={plates} 
                        onUpdateOrder={onUpdateOrder}
                    />
                    <DropdownMenuSeparator />
                    <DropdownMenuItem 
                        className="text-destructive"
                        onClick={() => onDeleteOrder(order.id)}
                    >
                        Delete Order
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <AlertDialog open={!!redirectingOrder}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Redirecting...</AlertDialogTitle>
            <AlertDialogDescription asChild>
              <div className="flex items-center justify-center p-4">
                <Loader2 className="mr-2 h-6 w-6 animate-spin" />
                <div>
                  Taking you to the details for order{" "}
                  <strong>{redirectingOrder?.orderNumber}</strong>.
                </div>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
