
"use client";

import * as React from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import type { Plate, Order } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  returnedItems: z.array(z.object({
    plateId: z.string(),
    damaged: z.coerce.number().int().nonnegative("Cannot be negative"),
    damagePricePerPiece: z.coerce.number().nonnegative("Cannot be negative"),
  })),
});

type ReturnOrderFormValues = z.infer<typeof formSchema>;

type ReturnOrderDialogProps = {
  order: Order & { items: { plateName: string; quantity: number, ratePerPiece: number }[] };
  plates: Plate[];
  setOrders: React.Dispatch<React.SetStateAction<Order[]>>;
  setPlates: React.Dispatch<React.SetStateAction<Plate[]>>;
};

export function ReturnOrderDialog({ order, plates, setOrders, setPlates }: ReturnOrderDialogProps) {
  const [open, setOpen] = React.useState(false);
  const { toast } = useToast();

  const defaultValues = React.useMemo(() => ({
    returnedItems: order.items.map(item => ({
      plateId: item.plateId,
      damaged: 0,
      damagePricePerPiece: item.ratePerPiece, // Default to rental rate
    })),
  }), [order.items]);

  const form = useForm<ReturnOrderFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues,
  });

  React.useEffect(() => {
    if (open) {
      form.reset(defaultValues);
    }
  }, [open, form, defaultValues]);

  const onSubmit = (values: ReturnOrderFormValues) => {
    const totalDamageFee = values.returnedItems.reduce((acc, item) => {
      return acc + (item.damaged * item.damagePricePerPiece);
    }, 0);

    // 1. Update the order
    setOrders(prevOrders =>
      prevOrders.map(o =>
        o.id === order.id
          ? { 
              ...o, 
              returned: true, 
              returnedItems: values.returnedItems, 
              returnDate: new Date(),
              rentalAmount: o.rentalAmount + totalDamageFee,
              damageFee: totalDamageFee
            }
          : o
      )
    );

    // 2. Update inventory for damaged plates
    setPlates(prevPlates => {
        const newPlates = [...prevPlates];
        values.returnedItems.forEach(returnedItem => {
            if (returnedItem.damaged > 0) {
                const plateIndex = newPlates.findIndex(p => p.id === returnedItem.plateId);
                if (plateIndex !== -1) {
                    newPlates[plateIndex].quantity -= returnedItem.damaged;
                    newPlates[plateIndex].damaged += returnedItem.damaged;
                }
            }
        });
        return newPlates;
    });

    toast({
        title: "Order Returned",
        description: `Order ${order.orderNumber} has been marked as returned. Damage fee of ${new Intl.NumberFormat("en-IN", { style: 'currency', currency: 'INR' }).format(totalDamageFee)} applied.`,
    });
    
    setOpen(false);
  };
  
  const watchedReturnedItems = form.watch("returnedItems");

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>Mark as Returned</Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Return Order {order.orderNumber}</DialogTitle>
          <DialogDescription>
            Enter the number of damaged plates.
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2">
              {order.items.map((orderItem, index) => {
                const plateName = plates.find(p => p.id === orderItem.plateId)?.name || 'Unknown Plate';
                const totalRented = orderItem.quantity;
                const currentDamaged = watchedReturnedItems[index]?.damaged || 0;
                
                if (currentDamaged > totalRented) {
                    form.setError(`returnedItems.${index}.damaged`, { type: 'custom', message: `Max: ${totalRented}`});
                } else if (form.formState.errors.returnedItems?.[index]?.damaged?.type === 'custom') {
                    form.clearErrors(`returnedItems.${index}.damaged`);
                }

                return (
                  <div key={orderItem.plateId} className="p-4 border rounded-lg space-y-3">
                    <h4 className="font-semibold">{plateName}</h4>
                    <p className="text-sm text-muted-foreground">
                        Rented: <strong>{totalRented}</strong>
                    </p>
                     <div className="grid grid-cols-2 gap-4 items-end">
                        <FormField
                            control={form.control}
                            name={`returnedItems.${index}.damaged`}
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Damaged Qty</FormLabel>
                                <FormControl>
                                    <Input 
                                        type="number" 
                                        placeholder="0" 
                                        {...field} 
                                        max={totalRented}
                                        min={0}
                                     />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                         <FormField
                            control={form.control}
                            name={`returnedItems.${index}.damagePricePerPiece`}
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Damage Rate</FormLabel>
                                <FormControl>
                                    <Input 
                                        type="number" 
                                        step="0.01"
                                        placeholder="0.00" 
                                        {...field}
                                        min={0}
                                     />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                    </div>
                  </div>
                );
              })}
            </div>
            <DialogFooter>
              <Button type="button" variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="submit">Confirm Return</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

    