
"use client";

import * as React from "react";
import { useLocalStorage } from "@/hooks/use-local-storage";
import OrdersTable from "./_components/orders-table";
import { Card, CardContent } from "@/components/ui/card";
import type { Order, Customer, Plate } from "@/lib/types";
import { CreateOrderDialog } from "./_components/create-order-dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { isFuture, isPast, isThisWeek } from "date-fns";


export default function OrdersPage() {
  const [orders, setOrders] = useLocalStorage<Order[]>("orders", []);
  const [customers] = useLocalStorage<Customer[]>("customers", []);
  const [plates] = useLocalStorage<Plate[]>("plates", []);
  const [activeTab, setActiveTab] = React.useState("all");
  const [isClient, setIsClient] = React.useState(false);

  React.useEffect(() => {
    setIsClient(true);
  }, []);

  const addOrder = (newOrder: Omit<Order, "id" | "orderNumber" | "returned" | "paymentStatus">) => {
    const maxOrderNumber = orders.reduce((max, order) => {
        const currentNum = parseInt(order.orderNumber.replace(/[^0-9]/g, ''), 10);
        return currentNum > max ? currentNum : max;
    }, 0);
    const newOrderNumber = maxOrderNumber + 1;

    const orderToAdd: Order = {
        ...newOrder,
        id: `o${Date.now()}`,
        orderNumber: `##${String(newOrderNumber).padStart(4, '0')}`,
        returned: false,
        paymentStatus: 'Pending',
    };

    setOrders((prev) => [orderToAdd, ...prev]);
  };


  const updateOrder = (
    orderId: string,
    updatedOrder: Partial<Omit<Order, "id">>
  ) => {
    
    const newOrders = orders.map((order) => {
      if (order.id === orderId) {
        return { ...order, ...updatedOrder };
      }
      return order;
    });

    setOrders(newOrders);
  };

  const deleteOrder = (orderId: string) => {
      const orderToDelete = orders.find(o => o.id === orderId);
      if (!orderToDelete) return;
      setOrders(prev => prev.filter(o => o.id !== orderId));
  }

  const ordersWithDetails = orders
    .map((order) => ({
      ...order,
      customerName:
        customers.find((c) => c.id === order.customerId)?.name || "Unknown",
      items: order.items.map((item) => ({
        ...item,
        plateName:
          plates.find((p) => p.id === item.plateId)?.name || "Unknown",
      })),
      rentalDate: new Date(order.rentalDate),
    }))
    .sort((a, b) => b.rentalDate.getTime() - a.rentalDate.getTime());

    const filteredOrders = ordersWithDetails.filter(order => {
        const orderDate = new Date(order.rentalDate);
        if (activeTab === 'upcoming') {
            return isFuture(orderDate) || isThisWeek(orderDate);
        }
        if (activeTab === 'this-week') {
            return isThisWeek(orderDate);
        }
        if (activeTab === 'past') {
            return isPast(orderDate) && !isThisWeek(orderDate);
        }
        return true; // 'all' tab
    });


  return (
    <div className="space-y-6">
       <Tabs value={activeTab} onValueChange={setActiveTab}>
        <div className="flex items-center justify-between">
          <TabsList>
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
            <TabsTrigger value="this-week">This Week</TabsTrigger>
            <TabsTrigger value="past">Past</TabsTrigger>
          </TabsList>
          <CreateOrderDialog customers={customers} plates={plates} onAddOrder={addOrder} />
        </div>
        <Card>
            <CardContent className="p-0">
                {isClient && (
                    <OrdersTable 
                        data={filteredOrders} 
                        customers={customers}
                        plates={plates}
                        onUpdateOrder={updateOrder} 
                        onDeleteOrder={deleteOrder}
                    />
                )}
            </CardContent>
        </Card>
      </Tabs>
    </div>
  );
}
