
"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Calendar as CalendarIcon, Trash2, IndianRupee, UtensilsCrossed, Wallet, TrendingUp, FileText } from "lucide-react";
import { useLocalStorage } from "@/hooks/use-local-storage";
import type { Order, Customer, Plate, Payment } from "@/lib/types";
import { format, startOfDay } from "date-fns";
import { Calendar } from "@/components/ui/calendar";

export default function Home() {
  const router = useRouter();
  const [orders] = useLocalStorage<Order[]>("orders", []);
  const [customers] = useLocalStorage<Customer[]>("customers", []);
  const [plates] = useLocalStorage<Plate[]>("plates", []);
  const [payments] = useLocalStorage<Payment[]>("payments", []);

  const totalBilled = orders.reduce((sum, o) => sum + o.rentalAmount + (o.damageFee || 0), 0);
  const totalRevenue = payments.reduce((sum, p) => sum + p.amount, 0);
  const totalOutstanding = totalBilled - totalRevenue;
  

  const upcomingEvents = orders
    .filter((o) => !o.returned && new Date(o.rentalDate) > new Date())
    .sort(
      (a, b) => new Date(a.rentalDate).getTime() - new Date(b.rentalDate).getTime()
    )
    .slice(0, 5);
    
  const deliveryDates = React.useMemo(() => {
    return orders
        .filter(order => !order.returned)
        .map(order => startOfDay(new Date(order.rentalDate)));
    }, [orders]);

    const handleDateSelect = (date: Date | undefined) => {
        if (date) {
            const dateString = format(date, "yyyy-MM-dd");
            router.push(`/delivery/${dateString}`);
        }
    };

  const handleClearData = () => {
    if (window.confirm("Are you sure you want to delete all data? This action cannot be undone.")) {
      window.localStorage.removeItem("plates");
      window.localStorage.removeItem("customers");
      window.localStorage.removeItem("orders");
      window.localStorage.removeItem("payments");
      window.location.reload();
    }
  };


  return (
    <div className="space-y-8">
        <Card>
            <CardHeader>
                <CardTitle className="text-xl font-bold font-headline">Delivery Schedule</CardTitle>
                <CardDescription>Select a date to view scheduled deliveries.</CardDescription>
            </CardHeader>
            <CardContent className="flex justify-center p-0 pb-4">
                <Calendar
                    mode="single"
                    onSelect={handleDateSelect}
                    className="p-0"
                    classNames={{
                        months: "flex flex-col sm:flex-row space-y-4 sm:space-x-4 sm:space-y-0",
                        month: "space-y-4 w-full",
                        table: "w-full border-collapse space-y-1",
                        head_row: "flex justify-between",
                        head_cell: "text-muted-foreground rounded-md w-full font-normal text-[0.8rem]",
                        row: "flex w-full mt-2 justify-between",
                        cell: "h-9 w-9 text-center text-sm p-0 relative [&:has([aria-selected].day-range-end)]:rounded-r-md [&:has([aria-selected].day-outside)]:bg-accent/50 [&:has([aria-selected])]:bg-accent first:[&:has([aria-selected])]:rounded-l-md last:[&:has([aria-selected])]:rounded-r-md focus-within:relative focus-within:z-20",
                        day: "h-9 w-9 p-0 font-normal aria-selected:opacity-100 rounded-full",
                        day_selected: "bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground focus:bg-primary focus:text-primary-foreground",
                        day_today: "bg-accent text-accent-foreground rounded-full",
                    }}
                    modifiers={{
                        delivery: deliveryDates,
                    }}
                    modifiersStyles={{
                        delivery: { 
                            fontWeight: 'bold',
                            color: 'hsl(var(--sidebar-primary))',
                            backgroundColor: 'hsl(var(--sidebar-primary-foreground))',
                            border: '1px solid hsl(var(--sidebar-primary))'
                            },
                    }}
                />
            </CardContent>
        </Card>
        
       <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <div onClick={() => router.push('/customers')} className="cursor-pointer">
            <Card className="hover:bg-muted/50 transition-colors">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                Total Revenue
                </CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">
                {new Intl.NumberFormat("en-IN", { style: 'currency', currency: 'INR' }).format(totalRevenue)}
                </div>
                <p className="text-xs text-muted-foreground">Total payments received</p>
            </CardContent>
            </Card>
        </div>
        <div onClick={() => router.push('/customers')} className="cursor-pointer">
            <Card className="hover:bg-muted/50 transition-colors">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Billed</CardTitle>
                <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">
                {new Intl.NumberFormat("en-IN", { style: 'currency', currency: 'INR' }).format(totalBilled)}
                </div>
                <p className="text-xs text-muted-foreground">Sum of all order amounts</p>
            </CardContent>
            </Card>
        </div>
        <div onClick={() => router.push('/customers')} className="cursor-pointer">
            <Card className="hover:bg-muted/50 transition-colors">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Outstanding Balance</CardTitle>
                <Wallet className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">
                {new Intl.NumberFormat("en-IN", { style: 'currency', currency: 'INR' }).format(totalOutstanding > 0 ? totalOutstanding : 0)}
                </div>
                <p className="text-xs text-muted-foreground">Total remaining to be collected</p>
            </CardContent>
            </Card>
        </div>
      </div>

       <div className="grid gap-6">
            <Card>
                <CardHeader>
                <CardTitle className="font-headline flex items-center gap-2">
                    <CalendarIcon className="h-5 w-5 text-accent" />
                    Upcoming Events
                </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                <Table>
                    <TableHeader>
                    <TableRow>
                        <TableHead className="font-headline">Customer</TableHead>
                        <TableHead className="font-headline">Event Date</TableHead>
                        <TableHead className="text-right font-headline">
                        Amount (INR)
                        </TableHead>
                    </TableRow>
                    </TableHeader>
                    <TableBody>
                    {upcomingEvents.length > 0 ? (
                        upcomingEvents.map((order: Order) => {
                        const customer = customers.find(
                            (c) => c.id === order.customerId
                        );
                        return (
                            <TableRow key={order.id} onClick={() => router.push(`/orders/${order.id}`)} className="cursor-pointer">
                            <TableCell>
                                <div className="font-medium">{customer?.name}</div>
                            </TableCell>
                            <TableCell>
                                {format(new Date(order.rentalDate), "PPP")}
                            </TableCell>
                            <TableCell className="text-right">
                                {new Intl.NumberFormat("en-IN").format(order.rentalAmount)}
                            </TableCell>
                            </TableRow>
                        );
                        })
                    ) : (
                        <TableRow>
                        <TableCell
                            colSpan={4}
                            className="text-center text-muted-foreground py-8"
                        >
                            No upcoming events.
                        </TableCell>
                        </TableRow>
                    )}
                    </TableBody>
                </Table>
                </CardContent>
            </Card>
       </div>
      <div className="flex justify-end">
        <Button onClick={handleClearData} variant="destructive" className="font-headline">
          <Trash2 className="mr-2 h-4 w-4" />
          Clear All Data
        </Button>
      </div>
    </div>
  );
}

    

    