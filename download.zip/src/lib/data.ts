import type { Plate, Customer, Order } from "./types";

export const plates: Plate[] = [];

export const customers: Customer[] = [];

export const orders: Order[] = [];
