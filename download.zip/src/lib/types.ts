

export type Plate = {
  id: string;
  name: string;
  quantity: number;
  damaged: number;
  ratePerPiece: number;
};

export type Customer = {
  id: string;
  name: string;
  phone: string;
  rentalHistory: string[]; // array of order IDs
  outstandingBalance: number; // in INR
};

export type OrderItem = {
  plateId: string;
  quantity: number;
  ratePerPiece: number;
};

export type Order = {
  id: string;
  orderNumber: string;
  customerId: string;
  items: OrderItem[];
  rentalDate: Date;
  session: "Morning" | "Noon" | "Evening";
  rentalAmount: number; // in INR
  damageFee?: number; // in INR
  returned: boolean;
  returnedItems?: {
    plateId: string;
    damaged: number;
    damagePricePerPiece: number;
  }[];
  paymentStatus: "Paid" | "Pending";
  auditorium?: string;
  returnDate?: Date;
};

export type Payment = {
    id: string;
    customerId: string;
    amount: number;
    paymentDate: Date;
};
